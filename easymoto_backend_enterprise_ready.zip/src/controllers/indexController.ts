import { Request, Response, NextFunction } from 'express';
import { getStatusService } from '../services/indexService';

export const getStatus = (req: Request, res: Response, next: NextFunction) => {
  try {
    const status = getStatusService();
    res.json({ status });
  } catch (err) {
    next(err);
  }
};