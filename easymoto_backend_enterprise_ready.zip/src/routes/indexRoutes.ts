import { Router } from 'express';
import { getStatus } from '../controllers/indexController';

const router = Router();

router.get('/status', getStatus);

export default router;