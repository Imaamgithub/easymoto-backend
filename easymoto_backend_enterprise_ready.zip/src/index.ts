import express, { Application, Request, Response } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import indexRoutes from './routes/indexRoutes';
import { errorHandler } from './middleware/errorHandler';

dotenv.config();

const app: Application = express();
app.use(cors());
app.use(express.json());

// Routes
app.use('/api', indexRoutes);

// Health check
app.get('/', (_req: Request, res: Response) => {
  res.send('Easymoto Backend is running!');
});

// Global error handler
app.use(errorHandler);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});