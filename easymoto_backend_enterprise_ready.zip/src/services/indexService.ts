export const getStatusService = () => {
  return 'Easymoto backend is operational';
};