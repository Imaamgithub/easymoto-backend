export const config = {
  appName: 'Easymoto Backend',
  port: process.env.PORT || 3000
};