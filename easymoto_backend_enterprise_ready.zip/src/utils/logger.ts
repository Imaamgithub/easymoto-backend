export const log = (message: string) => {
  console.log(`[Easymoto] ${message}`);
};